#!/usr/bin/env python
# coding: utf-8
! pip install visdom! pip install tqdm -U
# In[1]:


import os
import scipy.io
import h5py
import torch
import torch.optim as optim
import numpy as np
import torch.nn as nn
import torch.utils.data as Data
import torch.nn.functional as F
# import visdom
# import mkdir
import time
torch.manual_seed(1337)
np.random.seed(1337)
torch.cuda.manual_seed(1337)
torch.backends.cudnn.benchmark=True

from tqdm.notebook import tqdm


# In[2]:


## Hyper Parameters
EPOCH = 60
BATCH_SIZE = 100
LR = 0.001
# save_model_time = '0525'

# mkpath = 'model/model%s'% save_model_time
# mkdir.mkdir(mkpath)
#patience = 5


# In[3]:


os.chdir('/projects/aradml/mem')


# In[4]:


# print('starting loading the data')
trainmat = h5py.File('data_bak/train.mat')
# X_train = np.transpose(np.array(trainmat['trainxdata']),axes=(2,0,1))
X_train = np.transpose(np.array(trainmat['trainxdata']),axes=(2,1,0))
y_train = np.array(trainmat['traindata']).T


# In[5]:


validmat = scipy.io.loadmat('data_bak/valid.mat')
# valx_data =np.transpose(validmat['validxdata'],axes=(0,2,1))
valx_data =np.transpose(validmat['validxdata'],axes=(0,1,2))
val_data =validmat['validdata']

# np_valid_data = scipy.io.loadmat('valid.mat')

# validX_data = torch.FloatTensor(np_valid_data['validxdata'])
# validY_data = torch.FloatTensor(np_valid_data['validdata'])


# In[6]:


X_train.shape, y_train.shape, valx_data.shape, val_data.shape


# In[7]:


# X_train = X_train.reshape(X_train.shape[0],1,X_train.shape[1],X_train.shape[2])
# valx_data = valx_data.reshape(valx_data.shape[0],1,valx_data.shape[1],valx_data.shape[2])
# X_train = X_train.reshape(4400000, 1000, 4)
# valx_data = valx_data.reshape(8000, 1000, 4)


# In[8]:


X_train.shape, y_train.shape, valx_data.shape, val_data.shape


# In[9]:


print('compling the network')
class DanQ(nn.Module):
    def __init__(self, ):
        super(DanQ, self).__init__()
        self.Conv1 = nn.Conv1d(in_channels=4, out_channels=320, kernel_size=26)
        #self.Conv1.weight.data = torch.Tensor(np.load('conv1_weights.npy'))
        #self.Conv1.bias.data = torch.Tensor(np.load('conv1_bias.npy'))
        self.Maxpool = nn.MaxPool1d(kernel_size=13, stride=13)
        self.Drop1 = nn.Dropout(p=0.2)
        self.BiLSTM = nn.LSTM(input_size=320, hidden_size=320, num_layers=2,
                                 batch_first=True,
                                 dropout=0.5,
                                 bidirectional=True)
        self.Linear1 = nn.Linear(75*640, 925)
        self.Linear2 = nn.Linear(925, 919)

    def forward(self, input):
        x = self.Conv1(input)
        x = F.relu(x)
        x = self.Maxpool(x)
        x = self.Drop1(x)
        x_x = torch.transpose(x, 1, 2)
        x, (h_n,h_c) = self.BiLSTM(x_x)
        #x, h_n = self.BiGRU(x_x)
        x = x.contiguous().view(-1, 75*640)
        x = self.Linear1(x)
        x = F.relu(x)
        x = self.Linear2(x)
        return x


# In[10]:


def train_epoch(loader, optimizer):

    model.train()
    train_loss = []
    bar = tqdm(loader)
    for (data, target) in bar:
#         print(data.shape,target.shape)
        data, target = data.to(device), target.to(device)
#         loss_func = criterion
        optimizer.zero_grad()
        logits = model(data)
        loss = loss_func(logits, target)
        loss.backward()
        optimizer.step()

        loss_np = loss.detach().cpu().numpy()
        train_loss.append(loss_np)
        smooth_loss = sum(train_loss[-100:]) / min(len(train_loss), 100)
        bar.set_description('loss: %.5f, smth: %.5f' % (loss_np, smooth_loss))
    return train_loss


# In[11]:


def val_epoch(loader):

    model.eval()
    val_loss = []
    LOGITS = []
    PREDS = []
    TARGETS = []

    with torch.no_grad():
        for (data, target) in tqdm(loader):
            data, target = data.to(device), target.to(device)
            logits = model(data)

            loss = loss_func(logits, target)

            pred = logits.sigmoid().sum(1).detach().round()
            LOGITS.append(logits)
            PREDS.append(pred)
            TARGETS.append(target.sum(1))

            val_loss.append(loss.detach().cpu().numpy())
        val_loss = np.mean(val_loss)

        return val_loss


# In[12]:


params = {'batch_size': 512,'num_workers': 48}

valid_loader = Data.DataLoader(dataset=Data.TensorDataset(torch.FloatTensor(valx_data), torch.FloatTensor(val_data)), 
                shuffle=False,**params)
train_loader = Data.DataLoader(dataset=Data.TensorDataset(torch.FloatTensor(X_train), torch.FloatTensor(y_train)), 
                shuffle=False,**params)


# In[13]:


device = torch.device('cuda')
model = DanQ()
model = model.to(device)
# danq = DanQ()
# danq.cuda()


# In[14]:


print(model)
# model.


# In[15]:


optimizer = optim.RMSprop(model.parameters(), lr=LR)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=5,verbose=1)
loss_func = nn.BCEWithLogitsLoss()


# In[16]:


# train_loader


# In[17]:


## Hyper Parameters
n_epochs = 60
BATCH_SIZE = 100
LR = 0.001


# In[18]:


model.load_state_dict(torch.load('/projects/aradml/mem/new_wt/nopair_best_TL_99999.0_VL_99999.0.pth'))


# In[20]:


log_dir = '/projects/aradml/mem/logs'
kernel_type = 'nopair'
val_loss_min = 99999.
train_loss = 99999.
val_loss = 99999.


for epoch in range(1, n_epochs+1):
    print(time.ctime(), 'Epoch:', epoch)

    train_loss = train_epoch(train_loader, optimizer)
    val_loss = val_epoch(valid_loader)
    
#     scheduler.step(epoch-1)
    scheduler.step(val_loss)

    content = time.ctime() + ' ' + f'Epoch {epoch}, lr: {optimizer.param_groups[0]["lr"]:.7f}, train loss: {np.mean(train_loss):.5f}, val loss: {np.mean(val_loss):.5f}'
    print(content)
    with open(os.path.join(log_dir,f'log_{kernel_type}.txt'), 'a') as appender:
        appender.write(content + '\n')

    if val_loss < val_loss_min:
        print('score2 ({:.6f} --> {:.6f}).  Saving model ...'.format(val_loss_min, val_loss))
        best_file = f'{kernel_type}_best_TL_{np.mean(train_loss):.5f}_VL_{np.mean(val_loss):.5f}.pth'
        torch.save(model.state_dict(), os.path.join('new_wt',best_file))
        val_loss_min = val_loss

torch.save(model.state_dict(), os.path.join('new_wt',f'{kernel_type}_final_TL_{np.mean(train_loss):.5f}_VL_{np.mean(val_loss):.5f}.pth'))

