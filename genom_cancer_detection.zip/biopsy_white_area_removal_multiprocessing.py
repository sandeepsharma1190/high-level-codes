from multiprocessing import Pool
import pandas as pd
import os
import skimage.io
import numpy as np
import time

data_dir = '/projects/aradml/pc/full'
df_train = pd.read_csv(os.path.join(data_dir, 'train.csv'))
image_folder = os.path.join(data_dir, 'train_images')
image_clip_folder = os.path.join(data_dir,'train_images_clip')

def image_clip_save_mt(filename):
    data_dir = '/projects/aradml/pc/full'
    image_folder = os.path.join(data_dir, 'train_images')
    image_clip_folder = os.path.join(data_dir,'train_images_clip')
    indir=image_folder
    outdir=image_clip_folder
    img = skimage.io.MultiImage(os.path.join(indir, filename+'.tiff'))[-1]
    
    rows = img.shape[0]
    cols = img.shape[1]
    cols_needed = []
    rows_needed = []
    
    for j in np.arange(cols-1):
        if np.equal(img[:,j,0] , img[:,j+1,0]).sum() != rows:
            cols_needed.append(j)

    for k in np.arange(rows-1):
        if np.equal(img[k,:,0] , img[k+1,:,0]).sum() != cols:
            rows_needed.append(k)
            
    img_clip_temp = img[:,cols_needed, :]
    img_clip = img_clip_temp[rows_needed , : , : ]
    
    skimage.io.imsave(os.path.join(outdir,filename+'.png'),img_clip)
    return filename
	
	
start_time = time.time()
if __name__ == '__main__':

    dataset = list(df_train.iloc[:,0])


    agents = 32
    chunksize = 16
    with Pool(processes=agents) as pool:
        result = pool.map(image_clip_save_mt, dataset, chunksize)



end_time = time.time()

print("--- %s seconds ---" % (end_time - start_time))
