import os
os.chdir('/projects/aradml/mem')
import sys
sys.path.insert(0, '/projects/aradml/mem/keras-attention-mechanism')

import numpy as np
import h5py
import scipy.io
np.random.seed(1337) # for reproducibility

from keras.preprocessing import sequence
from keras.optimizers import RMSprop
from keras.models import Sequential, Model
from keras.layers import Dense, Dropout, Embedding, LSTM, Bidirectional, Input, Add, multiply, merge, Conv1D, MaxPooling1D, Multiply, Permute, Reshape, Concatenate, Convolution2D, MaxPooling2D, TimeDistributed, RNN, Lambda
from keras.layers.normalization import BatchNormalization
from keras import initializers, regularizers, constraints
from keras.layers.core import Dense, Dropout, Activation, Flatten
from keras.layers.convolutional import Convolution1D, MaxPooling1D
from keras.regularizers import l2, l1
from keras.constraints import maxnorm
from keras.layers.recurrent import LSTM, GRU
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras.engine.topology import Layer
from keras import backend as K
from keras_attention_block import *
from keras_tqdm import TQDMNotebookCallback
from clr_callback import *
from keras.layers.advanced_activations import LeakyReLU, PReLU, ELU
from keras.models import load_model
from keras.utils.vis_utils import plot_model

from attention_utils import get_activations, get_data_recurrent
from attention_lstm import attention_3d_block, model_attention_applied_after_lstm, model_attention_applied_before_lstm

#set gpu percentage, should not allocate complete gpu
import tensorflow as tf
#tf.enable_eager_execution()
#tf.executing_eagerly() 
gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=0.46)
#gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=2/16)

sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))

class Attention(Layer):
    def __init__(self, step_dim,
                 W_regularizer=None, b_regularizer=None,
                 W_constraint=None, b_constraint=None,
                 bias=True, **kwargs):
        self.supports_masking = True
        self.init = initializers.get('glorot_uniform')

        self.W_regularizer = regularizers.get(W_regularizer)
        self.b_regularizer = regularizers.get(b_regularizer)

        self.W_constraint = constraints.get(W_constraint)
        self.b_constraint = constraints.get(b_constraint)

        self.bias = bias
        self.step_dim = step_dim
        self.features_dim = 0
        super(Attention, self).__init__(**kwargs)

    def build(self, input_shape):
        assert len(input_shape) == 3

        self.W = self.add_weight((input_shape[-1],),
                                 initializer=self.init,
                                 name='{}_W'.format(self.name),
                                 regularizer=self.W_regularizer,
                                 constraint=self.W_constraint)
        self.features_dim = input_shape[-1]

        if self.bias:
            self.b = self.add_weight((input_shape[1],),
                                     initializer='zero',
                                     name='{}_b'.format(self.name),
                                     regularizer=self.b_regularizer,
                                     constraint=self.b_constraint)
        else:
            self.b = None

        self.built = True

    def compute_mask(self, input, input_mask=None):
        return None

    def call(self, x, mask=None):
        features_dim = self.features_dim
        step_dim = self.step_dim

        eij = K.reshape(K.dot(K.reshape(x, (-1, features_dim)),
                        K.reshape(self.W, (features_dim, 1))), (-1, step_dim))

        if self.bias:
            eij += self.b

        eij = K.tanh(eij)

        a = K.exp(eij)

        if mask is not None:
            a *= K.cast(mask, K.floatx())

        a /= K.cast(K.sum(a, axis=1, keepdims=True) + K.epsilon(), K.floatx())

        a = K.expand_dims(a)
        weighted_input = x * a
        return K.sum(weighted_input, axis=1)

    def compute_output_shape(self, input_shape):
        return input_shape[0],  self.features_dim
		
		
		
from keras.models import Model
from keras.layers import Dense, Embedding, Input
from keras.layers import LSTM, Bidirectional, Dropout


def BidLstm(maxlen, max_features, embed_size, embedding_matrix):
    inp = Input(shape=(maxlen, ))
    x = Embedding(max_features, embed_size, weights=[embedding_matrix],
                  trainable=False)(inp)
    x = Bidirectional(LSTM(300, return_sequences=True, dropout=0.25,
                           recurrent_dropout=0.25))(x)
    x = Attention(maxlen)(x)
    x = Dense(256, activation="relu")(x)
    x = Dropout(0.25)(x)
    x = Dense(6, activation="sigmoid")(x)
    model = Model(inputs=inp, outputs=x)

    return model
	
print ('loading data')
trainmat = h5py.File('data/train.mat')
validmat = scipy.io.loadmat('data/valid.mat')
testmat = scipy.io.loadmat('data/test.mat')

X_train = np.transpose(np.array(trainmat['trainxdata']),axes=(2,0,1))
y_train = np.array(trainmat['traindata']).T
valx_data =np.transpose(validmat['validxdata'],axes=(0,2,1))
val_data =validmat['validdata']


def attention_3d_block(inputs,time_steps):
    TIME_STEPS = time_steps
    # if True, the attention vector is shared across the input_dimensions where the attention is applied.
    SINGLE_ATTENTION_VECTOR = False

    input_dim = int(inputs.shape[2])
    a = Permute((2, 1),name='permute_1')(inputs)
    a = Reshape((input_dim,TIME_STEPS),name='reshape_1')(a)
    a = Dense(TIME_STEPS, activation='softmax',name='dense_1')(a)
    if SINGLE_ATTENTION_VECTOR:
        a = Lambda(lambda x: K.mean(x, axis=1), name='dim_reduction')(a)
        a = RepeatVector(input_dim)(a)
    a_probs = Permute((2, 1), name='attention_vec')(a)

    output_attention_mul = Multiply(name='attention_mul')([inputs, a_probs])
    return output_attention_mul


lstm_dim=320
num_class=919
inputs = Input(shape=(1000,4))
CNN_out = Convolution1D(filters=320, kernel_size=26, padding='valid',strides=1,name='conv1d_1')(inputs)
activation_1 = LeakyReLU(alpha=.3,name='leaky_re_lu_1')(CNN_out)
bn_1 = BatchNormalization(name='batch_normalization_1',momentum=0.9)(activation_1)
pool_out =MaxPooling1D(pool_size=13, strides=13,name='max_pooling1d_1')(bn_1)
drop_out_1= Dropout(0.2,name='dropout_1')(pool_out)
lstm_out = Bidirectional(LSTM(lstm_dim,return_sequences=True,dropout=0.5, recurrent_dropout=0.2),name='bidirectional_1')(drop_out_1)
attention_mul = attention_3d_block(lstm_out,int(pool_out.shape[1]))
attention_flatten_mul = Flatten(name='flatten_1')(attention_mul)
dense_2 = Dense(925, name='dense_2',activation='relu')(attention_flatten_mul)
bn_2 = BatchNormalization(name='batch_normalization_2',momentum=0.9)(dense_2)
output = Dense(num_class, activation='sigmoid',name='dense_3')(bn_2)
model = Model(inputs=inputs, outputs=output)

model.summary()
model_num = 'M016'

#clr_triangular = CyclicLR(mode='triangular')
#clr_triangular = CyclicLR(mode='triangular2')
#no range only triangular2 - vloss = .05200
# lr .0001 to .001 - M014-weights.03-0.05714-0.98162-0.05143-0.98360.hdf5
clr_triangular = CyclicLR(base_lr=0.0001, max_lr=0.001, mode='triangular2')
#clr_triangular._reset()
#clr_triangular = CyclicLR(mode='exp_range', gamma=0.99994)
#clr_triangular._reset()
#clr_triangular._reset(new_base_lr=0.003, new_max_lr=0.009)

print ('compiling model')

#model.compile(loss='binary_crossentropy', optimizer='rmsprop', metrics=['accuracy']) # , class_mode="binary"
model.compile(loss='binary_crossentropy', optimizer='nadam', metrics=['accuracy']) # , class_mode="binary"
#model.compile(loss={'Dense_final': 'sparse_categorical_crossentropy'}, optimizer='rmsprop', metrics={'Dense_final': 'categorical_accuracy'}) # , class_mode="binary"

print ('running at most 60 epochs')

checkpointer = ModelCheckpoint(filepath="/projects/aradml/mem/weights/"+model_num+"-weights.{epoch:02d}-{loss:.5f}-{acc:.5f}-{val_loss:.5f}-{val_acc:.5f}.hdf5", 
                               verbose=1,
                               monitor='val_loss',
                               save_best_only=True)

earlystopper = EarlyStopping(monitor='val_loss', 
                             patience=20, 
                             verbose=1)

model.load_weights('/projects/aradml/mem/weights/M014-weights.03-0.05714-0.98162-0.05143-0.98360.hdf5', skip_mismatch=True, by_name=True) #, skip_mismatch=True, by_name=True
#model = load_model('/projects/aradml/mem/weights/M014-weights.03-0.05714-0.98162-0.05143-0.98360.hdf5')
#model = load_model('/projects/aradml/mem/weights/M014-weights.13-0.05635-0.98177-0.05117-0.98368.hdf5')
#model = load_model('/projects/aradml/mem/weights/M014-weights.02-0.05574-0.98191-0.05114-0.98361.hdf5')
model.summary()


model.fit(x=X_train,
          y=y_train,
          batch_size = 500,
          epochs = 60,
          shuffle=True,
          verbose=0,
          validation_split=0.0,
          validation_data=(valx_data,val_data),
          class_weight=None,
          sample_weight=None,
          initial_epoch=0,
          callbacks=[checkpointer,earlystopper,TQDMNotebookCallback(metric_format='{name}: {value:0.5f}',leave_inner=True), clr_triangular])
		  
		  

tresults = model.evaluate(np.transpose(testmat['testxdata'],axes=(0,2,1)), testmat['testdata'],verbose=True)

print (tresults)


test_pred_data = model.predict(np.transpose(testmat['testxdata'],axes=(0,2,1)), verbose=True)

from sklearn.metrics import roc_curve, auc
fpr = dict()
tpr = dict()
roc_auc = dict()
n_classes = 919
for i in range(n_classes):
    fpr[i], tpr[i], _ = roc_curve(testmat['testdata'][:, i], test_pred_data[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Compute micro-average ROC curve and ROC area
fpr["micro"], tpr["micro"], _ = roc_curve(testmat['testdata'].ravel(), test_pred_data.ravel())
roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])


import matplotlib.pyplot as plt
plt.figure()
lw = 2
i = 1
plt.plot(fpr[i], tpr[i], color='darkorange',
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc[i])
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()
